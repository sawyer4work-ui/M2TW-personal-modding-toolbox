Fantastic Realms MODDB Builder v3.2 - source test release

Build on Windows 11 with BUILD_WINDOWS_11.bat, then run the resulting EXE.
Changes since v3.1:
- Removed unit diffuse and both attachment texture reuse options.
- Unit normal maps can be linked across all faction entries. Checking links
  existing entries to the first faction's normal; editing ANY linked entry
  updates every other one. Unchecking keeps values and allows independent edits.
- Browse dialogs remember the last selected folder separately for mesh,
  unit/attachment textures, and sprite files during this application session.
  Base-game asset directories are supported when the selected path contains
  unit_models or unit_sprites.
- Newly generated MODDB lines end in one trailing space; attachment normal
  lines end in two spaces after the final 0. Inherited template lines are
  preserved exactly (not reformatted).
- Existing Delete Faction location and confirmation are unchanged.

The MODDB file is READ ONLY. Output is for manual paste.
Compilation and in-game behavior must be tested on Windows by the user.
