Fantastic Realms MODDB Builder v3.0 — first test build

1. Extract the entire folder on Windows 11.
2. Double-click BUILD_WINDOWS_11.bat. The .NET Framework compiler builds the WinForms EXE in this folder.
3. Open a FORMATTED battle_models.modeldb. The original file is never modified.
4. Select a template. In NEW mode fields start blank; in Modify Existing mode fields are loaded from that entry.
5. Add factions; use separate expandable sections for unit textures/sprites and attachment textures.
6. Copy or save the generated entry; manually paste into your MODDB. For NEW entries increment global entry count by 1.
7. Stage .spr placeholders to a PREP folder and copy them into the mod manually.

IMPORTANT first-round limitations:
- Standard mesh headers '1 N' and '1.12 N' are supported (N=1..4). Rare unusual mesh headers, such as '1.12 0 0 3 0 0', are refused rather than rewritten incorrectly.
- The template ending, starting immediately after the last attachment texture line and including the terminator, is copied unchanged.
- Paths must be relative to unit_models/ or unit_sprites/. Browser selection accepts files beneath those named roots.
- Placeholder generation currently uses the base, ug1, ug2, ug3 template files and determines upgrade suffix from the generated sprite filename.
- Notepad++ is used if associated with .txt; otherwise the Windows default text editor or Notepad opens.
- This is C# source, not a precompiled EXE. Compile and test on Windows 11; it has not been compiled or tested in-game here.
