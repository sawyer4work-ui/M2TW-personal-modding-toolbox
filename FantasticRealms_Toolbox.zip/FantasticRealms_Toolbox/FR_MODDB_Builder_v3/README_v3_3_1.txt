FANTASTIC REALMS MODDB BUILDER v3.3.1 — CHECKER CORRECTION

This is a checker-only patch to v3.3. All builder, sprite, clipboard,
editor, and window layout logic is unchanged.

Whole-file checker updates:
- Recognizes the fourth, 13-field pony mount termination record.
- Supports unit faction texture records with either three lines (no sprite)
  or four lines (with sprite).
- Does not confuse mount skeleton lines with a missing attachment count.
- Counts and character-count checks remain read-only; line-numbered logs
  still go to logs/ beside the executable.

The supplied 935-entry MODDB was analyzed against the corrected checks.
Expected result: 935 entries, header 935, zero findings.

Build with BUILD_WINDOWS_11.bat on Windows 11. This source has not been
compiled on Windows in this environment. Keep the game-tested v3.2 and
working v3.3 installation until the new checker is confirmed.
