FANTASTIC REALMS MODDB BUILDER v3.3 — FINAL CANDIDATE

Based on the game-tested v3.2 source. Build with BUILD_WINDOWS_11.bat.
The application never writes to battle_models.modeldb.

Changes from v3.2:
- Copy Entry and Copy & Open Text Editor are side-by-side. The editor button
  copies to clipboard and launches Notepad++ (if found), else Notepad.
  It does NOT create a file or paste automatically; use Ctrl+V.
- Validate Entry and Check Whole MODDB File are side-by-side.
- Whole-file checker rereads the selected file from disk and writes a timestamped
  read-only, line-numbered report to logs/ in the tool directory.
  It checks global entry count, common character counts, standard mesh/faction
  group structure, and entry termination. Special mount entries get generic
  checks but are not subject to standard infantry block checks.
  This checker is not an engine compatibility test; review any reported findings.
- Sprite placeholders no longer require all texture paths. They are generated
  directly into unit_sprites/ next to the executable; existing files are skipped.
- File browsing remembers the last directory across all browse controls.
- Default window split gives more room to left-side controls.

Preserved from v3.2:
- Template ending inheritance, faction add/delete, optional linked unit normal
  maps, live preview, correct trailing spaces, and MODDB read-only behavior.
- Placeholder templates under placeholders/.

TESTING:
The source ZIP was prepared and checked for ZIP integrity in a non-Windows
runtime; compilation and in-game behavior require testing on Windows 11.
Keep your known-good v3.2 build as a fallback.
