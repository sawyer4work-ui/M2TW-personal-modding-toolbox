V3.1 TEST PATCH
- Fix faction and attachment UI containers to expand instead of remaining 5 pixels tall.
- Faction panels now use vertical flow layout rather than docked controls in autosized panels.
- Preview now updates with incomplete entries; copy/save/generation still require validation.
- Hide Modify Existing checkbox (new-entry workflow only; template selection still available).
- Rename Validate method to ValidateEntry to remove CS0108 warning.

Extract the archive to a NEW folder, run BUILD_WINDOWS_11.bat, and launch the new EXE.
This source is not compiled or Windows-tested in this environment.
