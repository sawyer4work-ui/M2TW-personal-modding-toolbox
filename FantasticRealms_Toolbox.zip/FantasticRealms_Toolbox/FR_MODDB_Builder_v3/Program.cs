using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace FRBuilderV3 {
 class Entry { public string Name; public string[] Lines; public Entry(string n,string[] l){Name=n;Lines=l;} public override string ToString(){return Name;} }
 class MeshDef { public string Path="",Distance="121"; }
 class FactionDef { public string Name="",Diffuse="",Normal="",Sprite="",AttachDiffuse="",AttachNormal=""; public bool ExistingSprite=false; }
 class Parsed {
  public string Name,MeshHeader; public List<MeshDef> Meshes=new List<MeshDef>(); public List<FactionDef> Factions=new List<FactionDef>(); public List<string> Tail=new List<string>();
 }
 class FactionControls {public FactionDef Data; public FlowLayoutPanel UnitPanel,AttachPanel;public ComboBox Faction;public TextBox Diffuse,Normal,Sprite,AttachDiffuse,AttachNormal;public RadioButton Generate,Existing;public Button UnitToggle,AttachToggle;public bool UnitOpen=true,AttachOpen=true;}
 class MainForm:Form {
  static readonly Regex End=new Regex(@"^(?:16 -0\.090000004 0 0 -0\.34999999 0\.80000001 0\.60000002|0 -1 0 0 0 0 0 0|0 0 -1 0 0 0 0 0 0)\s*$",RegexOptions.Compiled);
  static readonly Regex Counted=new Regex(@"^(\d+)\s+(.+?)\s*$",RegexOptions.Compiled);
  readonly List<Entry> entries=new List<Entry>(); readonly List<string> factions=new List<string>(); readonly List<FactionControls> factionControls=new List<FactionControls>(); readonly List<Tuple<TextBox,ComboBox>> meshControls=new List<Tuple<TextBox,ComboBox>>();
  readonly List<string> distances=new List<string>();
  string dbPath="",output=""; Parsed template; bool busy=false,hasEdits=false;
  TextBox search=new TextBox(),unit=new TextBox(),preview=new TextBox(),status=new TextBox(); ComboBox templates=new ComboBox(); CheckBox modify=new CheckBox(); NumericUpDown meshCount=new NumericUpDown(),spriteUpgrade=new NumericUpDown();
  CheckBox reuseNormal=new CheckBox();
  readonly Dictionary<string,string> lastFolders=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
  bool syncingNormal=false; string sharedNormal="";
  FlowLayoutPanel left=new FlowLayoutPanel(),meshArea=new FlowLayoutPanel(),unitArea=new FlowLayoutPanel(),attachArea=new FlowLayoutPanel();
  Label meshLabel=new Label();
  public MainForm(){
   Text="Fantastic Realms MODDB Builder v3.3 Final Candidate — MODDB remains read-only";Width=1600;Height=940;MinimumSize=new Size(1150,700);
   var split=new SplitContainer(){Dock=DockStyle.Fill,SplitterDistance=835};Controls.Add(split);
   left.Dock=DockStyle.Fill;left.FlowDirection=FlowDirection.TopDown;left.WrapContents=false;left.AutoScroll=true;left.Padding=new Padding(8);split.Panel1.Controls.Add(left);left.Resize+=(s,e)=>ResizeLeft();
   AddButton(left,"Open formatted battle_models.modeldb",OpenDb);
   AddLabel(left,"Search existing entries / templates");search=AddText(left);search.TextChanged+=(s,e)=>Filter();
   templates=new ComboBox(){DropDownStyle=ComboBoxStyle.DropDownList};AddControl(left,templates,34);templates.SelectedIndexChanged+=(s,e)=>ChooseTemplate();
   modify=new CheckBox(){Text="Modify Existing (otherwise create NEW entry)",AutoSize=true};AddControl(left,modify,30);modify.CheckedChanged+=(s,e)=>SwitchMode();modify.Visible=false;
   AddLabel(left,"01 — Unit model entry name");unit=AddText(left);unit.TextChanged+=(s,e)=>Changed();
   AddLabel(left,"02 — Number of .mesh files (1–4)");meshCount.Minimum=1;meshCount.Maximum=4;meshCount.Value=1;AddControl(left,meshCount,29);meshCount.ValueChanged+=(s,e)=>{RebuildMeshes();Changed();};
   AddLabel(left,"03–05 — Mesh paths and draw distances");SetupArea(meshArea);AddControl(left,meshArea,5);meshArea.AutoSize=true;meshArea.MinimumSize=new Size(600,0);
   AddLabel(left,"07–10 — Unit textures and sprites (click faction header to collapse)");
   AddButton(left,"Add Faction",AddFaction);
   reuseNormal=AddCheck(left,"Link unit normal maps across all factions");reuseNormal.CheckedChanged+=(s,e)=>NormalLinkChanged();
   SetupArea(unitArea);AddControl(left,unitArea,5);unitArea.AutoSize=true;unitArea.MinimumSize=new Size(600,0);
   AddLabel(left,"Sprite upgrade suffix (0 = base, 1–3 = _ug1 to _ug3)");spriteUpgrade.Minimum=0;spriteUpgrade.Maximum=3;AddControl(left,spriteUpgrade,29);spriteUpgrade.ValueChanged+=(s,e)=>Changed();
   AddButton(left,"Generate Sprite Placeholders into Prep Folder",Stage);
   AddLabel(left,"12–14 — Attachment textures (faction names follow unit assignments)");
   SetupArea(attachArea);AddControl(left,attachArea,5);attachArea.AutoSize=true;attachArea.MinimumSize=new Size(600,0);
   var outputButtons=new TableLayoutPanel(){Width=665,Height=37,ColumnCount=2,RowCount=1};
   outputButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));outputButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));
   var copyButton=new Button(){Text="Copy Entry",Dock=DockStyle.Fill};copyButton.Click+=(s,e)=>Copy();outputButtons.Controls.Add(copyButton,0,0);
   var editorButton=new Button(){Text="Copy && Open Text Editor",Dock=DockStyle.Fill};editorButton.Click+=(s,e)=>CopyAndOpenEditor();outputButtons.Controls.Add(editorButton,1,0);AddControl(left,outputButtons,37);
   var checkButtons=new TableLayoutPanel(){Width=665,Height=37,ColumnCount=2,RowCount=1};
   checkButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));checkButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,50));
   var validateButton=new Button(){Text="Validate Entry",Dock=DockStyle.Fill};validateButton.Click+=(s,e)=>ValidateEntry();checkButtons.Controls.Add(validateButton,0,0);
   var fileButton=new Button(){Text="Check Whole MODDB File",Dock=DockStyle.Fill};fileButton.Click+=(s,e)=>CheckWholeFile();checkButtons.Controls.Add(fileButton,1,0);AddControl(left,checkButtons,37);
   AddLabel(left,"The original MODDB is never changed. New entries require global header count +1.");
   var right=new Panel(){Dock=DockStyle.Fill,Padding=new Padding(8)};split.Panel2.Controls.Add(right);
   var heading=new Label(){Text="Full entry preview (live) — original template until you edit",Dock=DockStyle.Top,Height=34,Font=new Font(Font.FontFamily,10,FontStyle.Bold)};right.Controls.Add(heading);
   status=new TextBox(){Dock=DockStyle.Bottom,Height=76,ReadOnly=true,Multiline=true,ScrollBars=ScrollBars.Vertical};right.Controls.Add(status);
   preview=new TextBox(){Dock=DockStyle.Fill,ReadOnly=true,Multiline=true,WordWrap=false,ScrollBars=ScrollBars.Both,Font=new Font("Consolas",9)};right.Controls.Add(preview);preview.BringToFront();status.Text="Load a formatted MODDB to begin.";
   RebuildMeshes();
  }
  void ResizeLeft(){int w=Math.Max(430,left.ClientSize.Width-38);foreach(Control c in left.Controls){if(c.Tag as string=="wide")c.Width=w;}foreach(Control c in meshArea.Controls)c.Width=w-8;foreach(Control c in unitArea.Controls)c.Width=w-8;foreach(Control c in attachArea.Controls)c.Width=w-8;}
  void AddControl(FlowLayoutPanel p,Control c,int h){c.Margin=new Padding(2,3,2,3);c.Width=665;c.Height=h;c.Tag="wide";p.Controls.Add(c);}
  void AddLabel(FlowLayoutPanel p,string s){var l=new Label(){Text=s,AutoSize=false,Font=new Font(Font,FontStyle.Bold)};AddControl(p,l,23);}
  TextBox AddText(FlowLayoutPanel p){var t=new TextBox();AddControl(p,t,26);return t;}
  void AddButton(FlowLayoutPanel p,string title,Action fn){var b=new Button(){Text=title};AddControl(p,b,32);b.Click+=(s,e)=>{try{fn();}catch(Exception ex){MessageBox.Show(ex.ToString(),"Builder error");}};}
  CheckBox AddCheck(FlowLayoutPanel p,string title){var c=new CheckBox(){Text=title};AddControl(p,c,24);return c;}
  void SetupArea(FlowLayoutPanel p){p.FlowDirection=FlowDirection.TopDown;p.WrapContents=false;p.AutoSize=true;p.AutoSizeMode=AutoSizeMode.GrowAndShrink;p.Margin=new Padding(0);}
  static string Value(string line){var m=Counted.Match(line.Trim());return m.Success?m.Groups[2].Value:line.Trim();}
  static string C(string s){return s.Length+" "+s;}
  static string PathPart(string v,string extension){int i=v.IndexOf(extension,StringComparison.OrdinalIgnoreCase);return i<0?"":v.Substring(0,i+extension.Length);}
  static string TailPart(string v,string extension){int i=v.IndexOf(extension,StringComparison.OrdinalIgnoreCase);return i<0?"":v.Substring(i+extension.Length);}
  static bool IsFaction(string line){var m=Counted.Match(line.Trim());if(!m.Success)return false;int n;return int.TryParse(m.Groups[1].Value,out n)&&m.Groups[2].Value.Length==n&&Regex.IsMatch(m.Groups[2].Value,@"^[A-Za-z0-9_'-]+$");}
  static bool IsPath(string line,string ext){var p=PathPart(Value(line),ext);return p.Length>0&&(p.StartsWith("unit_models/",StringComparison.OrdinalIgnoreCase)||p.StartsWith("unit_sprites/",StringComparison.OrdinalIgnoreCase));}
  static bool TryParse(Entry e,out Parsed p,out string error){
   p=null;error="";var a=e.Lines; if(a.Length<8){error="Entry too short";return false;}var x=new Parsed();x.Name=e.Name;x.MeshHeader=a[1].Trim();
   var header=Regex.Match(x.MeshHeader,@"^(1|1\.12)\s+([1-4])$");if(!header.Success){error="Unsupported mesh header: "+x.MeshHeader;return false;}
   int meshNum=int.Parse(header.Groups[2].Value);int i=2;
   for(int k=0;k<meshNum;k++){if(i>=a.Length||!IsPath(a[i],".mesh")){error="Mesh record mismatch";return false;}var v=Value(a[i++]);x.Meshes.Add(new MeshDef(){Path=PathPart(v,".mesh"),Distance=TailPart(v,".mesh").Trim()});}
   // The count and repeating records are authoritative; no fixed positions are assumed.
   int texCount;if(i>=a.Length||!int.TryParse(a[i++].Trim(),out texCount)||texCount<0||texCount>100){error="Unit texture faction count missing";return false;}
   for(int k=0;k<texCount;k++){
    if(i+3>=a.Length||!IsFaction(a[i])||!IsPath(a[i+1],".texture")||!IsPath(a[i+2],".texture")||!IsPath(a[i+3],".spr")){error="Unit texture group mismatch at "+k;return false;}
    x.Factions.Add(new FactionDef(){Name=Value(a[i]),Diffuse=PathPart(Value(a[i+1]),".texture"),Normal=PathPart(Value(a[i+2]),".texture"),Sprite=PathPart(Value(a[i+3]),".spr"),ExistingSprite=true});i+=4;
   }
   int attCount;if(i>=a.Length||!int.TryParse(a[i++].Trim(),out attCount)||attCount<0||attCount>100){error="Attachment faction count missing";return false;}
   for(int k=0;k<attCount;k++){
    if(i+2>=a.Length||!IsFaction(a[i])||!IsPath(a[i+1],".texture")||!IsPath(a[i+2],".texture")){error="Attachment group mismatch at "+k;return false;}
    string name=Value(a[i]);var f=x.Factions.FirstOrDefault(z=>z.Name.Equals(name,StringComparison.OrdinalIgnoreCase));if(f!=null){f.AttachDiffuse=PathPart(Value(a[i+1]),".texture");f.AttachNormal=PathPart(Value(a[i+2]),".texture");}i+=3;
   }
   if(i>=a.Length||!End.IsMatch(a[a.Length-1].Trim())){error="Missing recognized termination";return false;}
   x.Tail.AddRange(a.Skip(i));p=x;return true;
  }
  void OpenDb(){using(var d=new OpenFileDialog(){Filter="Formatted MODDB|battle_models.modeldb|All files|*.*"})if(d.ShowDialog()==DialogResult.OK){
   dbPath=d.FileName;var lines=File.ReadAllLines(dbPath);entries.Clear();factions.Clear();distances.Clear();int start=1;
   for(int i=1;i<lines.Length;i++)if(End.IsMatch(lines[i].Trim())){if(start<i&&IsFaction(lines[start])){var block=lines.Skip(start).Take(i-start+1).ToArray();entries.Add(new Entry(Value(block[0]),block));}start=i+1;}
   var fset=new HashSet<string>(StringComparer.OrdinalIgnoreCase);var dset=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   foreach(var e in entries){Parsed p;string error;if(!TryParse(e,out p,out error))continue;foreach(var f in p.Factions)fset.Add(f.Name);foreach(var m in p.Meshes)if(m.Distance.Length>0)dset.Add(m.Distance);}
   factions.AddRange(fset.OrderBy(z=>z,StringComparer.OrdinalIgnoreCase));distances.AddRange(dset.OrderBy(z=>{int n;return int.TryParse(z,out n)?n:int.MaxValue;}));
   Filter();status.Text="Loaded "+entries.Count+" entries, "+factions.Count+" factions, "+distances.Count+" draw distances. Original file is read-only.";
  }}
  void Filter(){var prior=templates.SelectedItem as Entry;busy=true;templates.Items.Clear();string q=search.Text.Trim();foreach(var e in entries.Where(x=>x.Name.IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0))templates.Items.Add(e);busy=false;
   if(prior!=null){for(int i=0;i<templates.Items.Count;i++)if(((Entry)templates.Items[i]).Name==prior.Name){templates.SelectedIndex=i;return;}}
   if(templates.Items.Count>0)templates.SelectedIndex=0;
  }
  void ChooseTemplate(){if(busy)return;var e=templates.SelectedItem as Entry;if(e==null)return;Parsed parsed;string error;if(!TryParse(e,out parsed,out error)){status.Text="Template cannot be safely parsed: "+error+". Select another entry.";return;}
   template=parsed;
   if(!hasEdits){busy=true;unit.Text=modify.Checked?parsed.Name:"";meshCount.Value=modify.Checked?parsed.Meshes.Count:1;spriteUpgrade.Value=0;RebuildMeshes();ClearFactions();if(modify.Checked){for(int i=0;i<parsed.Meshes.Count;i++){meshControls[i].Item1.Text=parsed.Meshes[i].Path;meshControls[i].Item2.Text=parsed.Meshes[i].Distance;}foreach(var f in parsed.Factions)AddFactionRow(Clone(f));}busy=false;}
   // Once edited, switching templates affects ONLY the inherited ending block.
   if(!hasEdits){preview.Text=string.Join("\r\n",e.Lines)+"\r\n";output="";status.Text="Template "+e.Name+" selected. "+(modify.Checked?"Modify mode populated.":"New entry fields blank.")+" Edit a field to see the generated entry.";}
   else Render();
  }
  static FactionDef Clone(FactionDef f){return new FactionDef(){Name=f.Name,Diffuse=f.Diffuse,Normal=f.Normal,Sprite=f.Sprite,AttachDiffuse=f.AttachDiffuse,AttachNormal=f.AttachNormal,ExistingSprite=f.ExistingSprite};}
  void SwitchMode(){if(template==null)return;busy=true;hasEdits=false;unit.Text=modify.Checked?template.Name:"";meshCount.Value=modify.Checked?template.Meshes.Count:1;spriteUpgrade.Value=0;RebuildMeshes();ClearFactions();if(modify.Checked){for(int i=0;i<template.Meshes.Count;i++){meshControls[i].Item1.Text=template.Meshes[i].Path;meshControls[i].Item2.Text=template.Meshes[i].Distance;}foreach(var f in template.Factions)AddFactionRow(Clone(f));}busy=false;var e=templates.SelectedItem as Entry;if(e!=null)preview.Text=string.Join("\r\n",e.Lines)+"\r\n";output="";status.Text=modify.Checked?"Modify Existing: selected entry populated.":"New entry: fields cleared.";}
  void RebuildMeshes(){if(meshArea==null)return;var prior=meshControls.Select(x=>new MeshDef(){Path=x.Item1.Text,Distance=x.Item2.Text}).ToList();meshArea.Controls.Clear();meshControls.Clear();for(int i=0;i<(int)meshCount.Value;i++){
    var panel=new TableLayoutPanel(){Width=655,Height=55,ColumnCount=3,RowCount=2,Margin=new Padding(2)};panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,105));panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,80));panel.RowStyles.Add(new RowStyle(SizeType.Absolute,20));panel.RowStyles.Add(new RowStyle(SizeType.Absolute,31));
    var lbl=new Label(){Text="Mesh "+(i+1)+" path",Dock=DockStyle.Fill};panel.Controls.Add(lbl,0,0);var dl=new Label(){Text="Draw distance",Dock=DockStyle.Fill};panel.Controls.Add(dl,1,0);
    var path=new TextBox(){Dock=DockStyle.Fill};var dist=new ComboBox(){Dock=DockStyle.Fill,DropDownStyle=ComboBoxStyle.DropDown};dist.Items.AddRange(distances.Cast<object>().ToArray());dist.Text=prior.Count>i?prior[i].Distance:(distances.Count>0?distances[0]:"121");path.Text=prior.Count>i?prior[i].Path:"";path.TextChanged+=(s,e)=>Changed();dist.TextChanged+=(s,e)=>Changed();
    panel.Controls.Add(path,0,1);panel.Controls.Add(dist,1,1);var browse=new Button(){Text="Browse",Dock=DockStyle.Fill};browse.Click+=(s,e)=>Browse(path,".mesh","unit_models");panel.Controls.Add(browse,2,1);meshArea.Controls.Add(panel);meshControls.Add(Tuple.Create(path,dist));
   }ResizeLeft();}
  void ClearFactions(){unitArea.Controls.Clear();attachArea.Controls.Clear();factionControls.Clear();sharedNormal="";}
  void AddFaction(){var f=new FactionDef();if(reuseNormal.Checked && factionControls.Count>0)f.Normal=sharedNormal;AddFactionRow(f);Changed();}
  void NormalLinkChanged(){
   if(busy)return;
   if(reuseNormal.Checked){
    // Checking links every existing faction to the first faction's current normal.
    sharedNormal=factionControls.Count>0?factionControls[0].Data.Normal:"";
    ApplySharedNormal();
   }
   Changed();
  }
  void ApplySharedNormal(){
   if(syncingNormal)return;
   syncingNormal=true;
   try{foreach(var c in factionControls){c.Data.Normal=sharedNormal;if(c.Normal!=null && c.Normal.Text!=sharedNormal)c.Normal.Text=sharedNormal;}}
   finally{syncingNormal=false;}
  }
  void NormalChanged(FactionControls source,string value){
   source.Data.Normal=value;
   if(reuseNormal.Checked && !syncingNormal){sharedNormal=value;ApplySharedNormal();}
   Changed();
  }
  void AddFactionRow(FactionDef f){var c=new FactionControls(){Data=f};factionControls.Add(c);
   c.UnitPanel=NewFactionPanel();c.AttachPanel=NewFactionPanel();unitArea.Controls.Add(c.UnitPanel);attachArea.Controls.Add(c.AttachPanel);
   c.UnitToggle=new Button(){Text="▼ "+Header(c),TextAlign=ContentAlignment.MiddleLeft,Height=29,Width=625};c.UnitPanel.Controls.Add(c.UnitToggle);
   var body=new FlowLayoutPanel(){Width=630,AutoSize=true,WrapContents=false,FlowDirection=FlowDirection.TopDown};c.UnitPanel.Controls.Add(body);
   c.Faction=new ComboBox(){DropDownStyle=ComboBoxStyle.DropDownList,Width=550};c.Faction.Items.AddRange(factions.Cast<object>().ToArray());if(f.Name.Length>0 && c.Faction.Items.Contains(f.Name))c.Faction.SelectedItem=f.Name;else if(f.Name.Length>0){c.Faction.Items.Add(f.Name);c.Faction.SelectedItem=f.Name;}
   var row=new FlowLayoutPanel(){Width=630,Height=32,WrapContents=false};row.Controls.Add(c.Faction);var del=new Button(){Text="Delete",Width=69};row.Controls.Add(del);del.Click+=(s,e)=>DeleteFaction(c);body.Controls.Add(row);
   c.Faction.SelectedIndexChanged+=(s,e)=>{f.Name=c.Faction.Text;c.UnitToggle.Text="▼ "+Header(c);c.AttachToggle.Text="▼ "+Header(c);Changed();};
   c.Diffuse=PathRow(body,"Faction diffuse",f.Diffuse,".texture","unit_models",v=>{f.Diffuse=v;Changed();});
   c.Normal=PathRow(body,"Unit normal map",f.Normal,".texture","unit_models",v=>NormalChanged(c,v));
   var modes=new FlowLayoutPanel(){Width=630,Height=28,WrapContents=false};c.Generate=new RadioButton(){Text="Generate placeholder",Width=175,Checked=!f.ExistingSprite};c.Existing=new RadioButton(){Text="Select existing .spr",Width=180,Checked=f.ExistingSprite};modes.Controls.Add(c.Generate);modes.Controls.Add(c.Existing);body.Controls.Add(modes);
   c.Sprite=PathRow(body,"Sprite path",f.Sprite,".spr","unit_sprites",v=>{f.Sprite=v;Changed();});
   c.Generate.CheckedChanged+=(s,e)=>{f.ExistingSprite=!c.Generate.Checked;c.Sprite.ReadOnly=c.Generate.Checked;Changed();};c.Sprite.ReadOnly=c.Generate.Checked;
   c.UnitToggle.Click+=(s,e)=>{c.UnitOpen=!c.UnitOpen;body.Visible=c.UnitOpen;c.UnitToggle.Text=(c.UnitOpen?"▼ ":"▶ ")+Header(c);};
   c.AttachToggle=new Button(){Text="▼ "+Header(c),TextAlign=ContentAlignment.MiddleLeft,Height=29,Width=625};c.AttachPanel.Controls.Add(c.AttachToggle);
   var abody=new FlowLayoutPanel(){Width=630,AutoSize=true,WrapContents=false,FlowDirection=FlowDirection.TopDown};c.AttachPanel.Controls.Add(abody);
   c.AttachDiffuse=PathRow(abody,"Attachment faction diffuse",f.AttachDiffuse,".texture","unit_models",v=>{f.AttachDiffuse=v;Changed();});
   c.AttachNormal=PathRow(abody,"Attachment normal map",f.AttachNormal,".texture","unit_models",v=>{f.AttachNormal=v;Changed();});
   c.AttachToggle.Click+=(s,e)=>{c.AttachOpen=!c.AttachOpen;abody.Visible=c.AttachOpen;c.AttachToggle.Text=(c.AttachOpen?"▼ ":"▶ ")+Header(c);};
   UpdateSprite(c);ResizeLeft();
  }
  static FlowLayoutPanel NewFactionPanel(){return new FlowLayoutPanel(){Width=650,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,FlowDirection=FlowDirection.TopDown,WrapContents=false,BorderStyle=BorderStyle.FixedSingle,Margin=new Padding(2,3,2,5)};}
  static string Header(FactionControls c){return c.Data.Name.Length>0?c.Data.Name:"(select faction)";}
  TextBox PathRow(FlowLayoutPanel area,string label,string initial,string extension,string root,Action<string> changed){
   var group=new FlowLayoutPanel(){Width=630,Height=52,FlowDirection=FlowDirection.TopDown,WrapContents=false,Margin=new Padding(2,1,2,1)};
   group.Controls.Add(new Label(){Text=label,Width=625,Height=18});var row=new FlowLayoutPanel(){Width=625,Height=30,WrapContents=false};var path=new TextBox(){Width=525,Text=initial};path.TextChanged+=(s,e)=>changed(path.Text);row.Controls.Add(path);var b=new Button(){Text="Browse",Width=85};b.Click+=(s,e)=>Browse(path,extension,root);row.Controls.Add(b);group.Controls.Add(row);area.Controls.Add(group);return path;
  }
  void DeleteFaction(FactionControls c){if(MessageBox.Show("Delete faction '"+Header(c)+"' from BOTH unit texture and attachment sections?\n\nCheck export_descr_unit.txt (EDU) before and after removing this assignment. A unit may still reference this model for this faction.","Confirm faction deletion",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes)return;unitArea.Controls.Remove(c.UnitPanel);attachArea.Controls.Remove(c.AttachPanel);c.UnitPanel.Dispose();c.AttachPanel.Dispose();factionControls.Remove(c);Changed();}
  void Browse(TextBox target,string ext,string root){using(var d=new OpenFileDialog(){Filter=ext+" files|*"+ext+"|All files|*.*",CheckFileExists=true,RestoreDirectory=true}){
   string initial;
   if(lastFolders.TryGetValue("last",out initial) && Directory.Exists(initial))d.InitialDirectory=initial;
   else if(dbPath.Length>0){string baseDir=Path.GetDirectoryName(dbPath);string candidate=Path.Combine(baseDir,root);d.InitialDirectory=Directory.Exists(candidate)?candidate:baseDir;}
   if(d.ShowDialog()!=DialogResult.OK)return;
   string normalized=d.FileName.Replace('\\','/');int index=normalized.LastIndexOf("/"+root+"/",StringComparison.OrdinalIgnoreCase);
   if(index<0){MessageBox.Show("The selected file must be within a '"+root+"' directory (in the mod or base game's data).\nNo path was changed.","Path outside expected root");return;}
   lastFolders["last"]=Path.GetDirectoryName(d.FileName);
   target.Text=normalized.Substring(index+1);
  }}
  // Match the formatted MODDB's trailing whitespace; inherited template lines are never altered.
  static string FormattedLine(string line,bool attachmentNormal=false){return line.TrimEnd(' ','\t')+(attachmentNormal?"  ":" ");}
  void Changed(){if(busy)return;hasEdits=true;Render();}
  void UpdateSprite(FactionControls c){if(c.Generate!=null&&c.Generate.Checked){string name=unit.Text.Trim();string f=c.Data.Name;if(name.Length>0&&f.Length>0){string sprite="unit_sprites/"+f+"_"+name+(spriteUpgrade.Value>0?"_ug"+spriteUpgrade.Value.ToString():"")+"_sprite.spr";c.Data.Sprite=sprite;if(c.Sprite.Text!=sprite){bool was=busy;busy=true;c.Sprite.Text=sprite;busy=was;}}}}
  bool Build(out string reason){reason="";output="";if(template==null){reason="Select a parseable template.";return false;}string name=unit.Text.Trim();if(!Regex.IsMatch(name,@"^[A-Za-z0-9_'-]+$")){reason="Enter a valid new unit name.";return false;}
   var m=new List<MeshDef>();foreach(var t in meshControls){string p=t.Item1.Text.Trim().Replace('\\','/');string d=t.Item2.Text.Trim();if(!p.StartsWith("unit_models/",StringComparison.OrdinalIgnoreCase)||!p.EndsWith(".mesh",StringComparison.OrdinalIgnoreCase)||!Regex.IsMatch(d,@"^\d+$")){reason="Every mesh needs a unit_models/ path and numeric draw distance.";return false;}m.Add(new MeshDef(){Path=p,Distance=d});}
   if(factionControls.Count==0){reason="Add at least one faction.";return false;}
   var fs=new List<FactionDef>();foreach(var c in factionControls){UpdateSprite(c);var f=c.Data;if(f.Name.Length==0){reason="Select every faction.";return false;}foreach(var path in new[]{f.Diffuse,f.Normal,f.AttachDiffuse,f.AttachNormal})if(!path.Replace('\\','/').StartsWith("unit_models/",StringComparison.OrdinalIgnoreCase)||!path.EndsWith(".texture",StringComparison.OrdinalIgnoreCase)){reason="Missing/invalid texture path for "+f.Name;return false;}if(!f.Sprite.StartsWith("unit_sprites/",StringComparison.OrdinalIgnoreCase)||!f.Sprite.EndsWith(".spr",StringComparison.OrdinalIgnoreCase)){reason="Missing sprite path for "+f.Name;return false;}fs.Add(f);}
   if(fs.Select(x=>x.Name).Distinct(StringComparer.OrdinalIgnoreCase).Count()!=fs.Count){reason="Duplicate factions are not allowed.";return false;}
   var a=new List<string>();a.Add(C(name));string prefix=template.MeshHeader.StartsWith("1.12 ")?"1.12 ":"1 ";a.Add(prefix+m.Count);foreach(var x in m)a.Add(C(x.Path)+" "+x.Distance);
   a.Add(fs.Count.ToString());foreach(var f in fs){a.Add(C(f.Name));a.Add(C(f.Diffuse.Replace('\\','/')));a.Add(C(f.Normal.Replace('\\','/')));a.Add(C(f.Sprite.Replace('\\','/')));}
   a.Add(fs.Count.ToString());foreach(var f in fs){a.Add(C(f.Name));a.Add(C(f.AttachDiffuse.Replace('\\','/')));a.Add(C(f.AttachNormal.Replace('\\','/'))+" 0");}
   int generatedCount=a.Count;int attachmentStart=generatedCount-fs.Count*3;
   for(int i=0;i<generatedCount;i++)a[i]=FormattedLine(a[i],i>=attachmentStart && (i-attachmentStart)%3==2);
   a.AddRange(template.Tail);output=string.Join("\r\n",a)+"\r\n";return true;
  }
  void Render(){if(template==null)return;string reason;bool valid=Build(out reason);if(!valid){
    // Show the evolving entry even while some required fields are still blank.
    var lines=new List<string>();string name=unit.Text.Trim();lines.Add(C(name));lines.Add("1 "+meshControls.Count);
    foreach(var t in meshControls){string path=t.Item1.Text.Trim().Replace('\\','/');lines.Add(C(path)+" "+t.Item2.Text.Trim());}
    lines.Add(factionControls.Count.ToString());
    foreach(var c in factionControls){UpdateSprite(c);var f=c.Data;lines.Add(C(f.Name));lines.Add(C(f.Diffuse));lines.Add(C(f.Normal));lines.Add(C(f.Sprite));}
    lines.Add(factionControls.Count.ToString());
    foreach(var c in factionControls){var f=c.Data;lines.Add(C(f.Name));lines.Add(C(f.AttachDiffuse));lines.Add(C(f.AttachNormal)+" 0");}
    int generatedCount=lines.Count;int attachmentStart=generatedCount-factionControls.Count*3;
    for(int i=0;i<generatedCount;i++)lines[i]=FormattedLine(lines[i],i>=attachmentStart && (i-attachmentStart)%3==2);
    lines.AddRange(template.Tail);output=string.Join("\r\n",lines)+"\r\n";
   }

   int first=preview.SelectionStart;int top=preview.GetLineFromCharIndex(first);preview.Text=output;int at=preview.GetFirstCharIndexFromLine(Math.Min(top,preview.Lines.Length-1));preview.SelectionStart=Math.Max(0,at);preview.ScrollToCaret();
   status.Text=(valid?"Live entry: ":"INCOMPLETE PREVIEW (not ready to copy/save): "+reason+" | ")+unit.Text+" | "+meshControls.Count+" meshes | "+factionControls.Count+" factions | template ending preserved from "+((Entry)templates.SelectedItem).Name+". "+(modify.Checked?"Modify existing: no global count change.":"NEW entry: increase global MODDB count by ONE.");
  }
  void Copy(){string reason;if(!Build(out reason)){MessageBox.Show(reason);return;}Clipboard.SetText(output);MessageBox.Show(modify.Checked?"Entry copied. Original MODDB unchanged.":"Entry copied. Remember to increase the global MODDB entry count by ONE.");}
  void CopyAndOpenEditor(){
   string reason;if(!Build(out reason)){MessageBox.Show(reason);return;}
   Clipboard.SetText(output);
   try{
    // Prefer an existing Notepad++ installation; never create a file or paste automatically.
    var candidates=new List<string>();
    string pf=Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
    string pf86=Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
    candidates.Add(Path.Combine(pf,"Notepad++","notepad++.exe"));
    candidates.Add(Path.Combine(pf86,"Notepad++","notepad++.exe"));
    string editor=candidates.FirstOrDefault(File.Exists);
    if(editor!=null)Process.Start(editor);
    else {try{Process.Start("notepad++.exe");}catch{Process.Start("notepad.exe");}}
    status.Text="Entry copied to clipboard. Paste it into your editor with Ctrl+V. The MODDB was not changed.";
   }catch(Exception ex){MessageBox.Show("Entry copied, but editor could not be opened: "+ex.Message);}
  }
  void Stage(){
   // Placeholder generation needs only the faction and unit name, not texture or mesh validation.
   if(unit.Text.Trim().Length==0){MessageBox.Show("Enter a unit model name before generating sprites.");return;}
   var requested=factionControls.Where(x=>x.Generate.Checked).ToList();
   if(requested.Count==0){MessageBox.Show("No factions are set to Generate Placeholder.");return;}
   foreach(var c in requested){
    if(c.Data.Name.Length==0){MessageBox.Show("Select the faction for every requested placeholder.");return;}
    UpdateSprite(c);
    if(!Regex.IsMatch(c.Data.Sprite,@"^unit_sprites/[A-Za-z0-9_'-]+\.spr$",RegexOptions.IgnoreCase)){
     MessageBox.Show("Invalid generated sprite name for "+c.Data.Name);return;
    }
   }
   string dest=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"unit_sprites");
   Directory.CreateDirectory(dest);int created=0,skipped=0;
   foreach(var c in requested){
    string file=Path.GetFileName(c.Data.Sprite);
    var match=Regex.Match(file,@"_ug([123])_sprite\.spr$",RegexOptions.IgnoreCase);
    string suffix=match.Success?"_ug"+match.Groups[1].Value:"";
    string src=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"placeholders","slave_dummy_en_spearmen"+suffix+"_sprite.spr");
    if(!File.Exists(src)){MessageBox.Show("Missing placeholder: "+src);return;}
    string target=Path.Combine(dest,file);
    if(File.Exists(target)){skipped++;continue;}
    File.Copy(src,target);created++;
   }
   MessageBox.Show("Created "+created+" .spr placeholders; skipped "+skipped+" existing.\n"+dest+"\nCopy them into your mod manually.");
  }
  void CheckWholeFile(){
   string path=dbPath;
   using(var d=new OpenFileDialog(){Filter="MODDB files|battle_models.modeldb|All files|*.*",FileName=File.Exists(dbPath)?dbPath:"battle_models.modeldb",InitialDirectory=File.Exists(dbPath)?Path.GetDirectoryName(dbPath):AppDomain.CurrentDomain.BaseDirectory}){
    if(d.ShowDialog()!=DialogResult.OK)return;path=d.FileName;
   }
   try{
    var result=WholeFileChecker.Check(path);
    string logs=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"logs");Directory.CreateDirectory(logs);
    string log=Path.Combine(logs,"MODDB_Check_"+DateTime.Now.ToString("yyyyMMdd_HHmmss")+".txt");
    File.WriteAllText(log,result,Encoding.UTF8);
    MessageBox.Show("Read-only check complete. Log saved to:\n"+log+"\n\nOpen the log to review line-numbered findings.","MODDB file check");
    try{Process.Start(new ProcessStartInfo(){FileName=log,UseShellExecute=true});}catch{Process.Start("notepad.exe","\""+log+"\"");}
   }catch(Exception ex){MessageBox.Show("Checker failed without changing the MODDB:\n"+ex.Message);}
  }
  void ValidateEntry(){string reason;if(!Build(out reason)){MessageBox.Show(reason);return;}Parsed p;string error;var e=new Entry(unit.Text,output.Replace("\r","").Split(new[]{'\n'},StringSplitOptions.RemoveEmptyEntries));if(!TryParse(e,out p,out error)){MessageBox.Show("Generated entry did not pass parser: "+error);return;}MessageBox.Show("Structure parsed: "+p.Meshes.Count+" meshes, "+p.Factions.Count+" unit factions, ending preserved.\nThis is NOT a guarantee of in-game compatibility.","Basic validation");}
 }
 static class WholeFileChecker {
  // Read-only checks. Never treat a termination or an uncounted numeric field as a string.
  static readonly Regex Term=new Regex(@"^(?:16 -0\.090000004 0 0 -0\.34999999 0\.80000001 0\.60000002|0 -1 0 0 0 0 0 0|0 0 -1 0 0 0 0 0 0|0 0 0 0 -1 0 0 0 0 0 0 0 0)\s*$");
  static readonly Regex Counted=new Regex(@"^(\d+)\s+(.+?)\s*$");
  static readonly Regex PathExt=new Regex(@"\.(?:mesh|texture|spr)(?=\s|$)",RegexOptions.IgnoreCase);
  static void Add(List<string> errors,int line,string message){errors.Add("Line "+line+": "+message);}
  static bool Numeric(string v,out int n){return int.TryParse(v.Trim(),out n);}
  static bool IsFaction(string line){
   var m=Counted.Match(line.Trim());int n;
   return m.Success&&int.TryParse(m.Groups[1].Value,out n)&&m.Groups[2].Value.Length==n&&Regex.IsMatch(m.Groups[2].Value,@"^[A-Za-z0-9_'-]+$");
  }
  static bool HasPath(string line,string ext){return line.IndexOf(ext,StringComparison.OrdinalIgnoreCase)>=0;}
  static void CheckCount(string line,int lineNo,List<string> errors){
   var m=Counted.Match(line.Trim());if(!m.Success)return;
   int declared;if(!int.TryParse(m.Groups[1].Value,out declared))return;
   string remainder=m.Groups[2].Value;
   var file=PathExt.Match(remainder);
   string value=file.Success?remainder.Substring(0,file.Index+file.Length):remainder.Split(new[]{' ','\t'},StringSplitOptions.RemoveEmptyEntries)[0];
   if(value.Length!=declared)Add(errors,lineNo,"Character count "+declared+" does not match "+value.Length+" for '"+value+"'.");
  }
  static bool IsCountedPath(string line,string ext){
   var m=Counted.Match(line.Trim());return m.Success&&m.Groups[2].Value.IndexOf(ext,StringComparison.OrdinalIgnoreCase)>=0;
  }
  static void CheckStandard(string[] lines,int start,int end,List<string> errors){
   int i=start+1;if(i>=end)return;
   var mesh=Regex.Match(lines[i].Trim(),@"^1\s+([0-9]+)$");
   if(!mesh.Success)return; // Different mount/special header.
   int count=int.Parse(mesh.Groups[1].Value);i++;
   if(count>100){Add(errors,start+2,"Implausible mesh count "+count+".");return;}
   for(int k=0;k<count;k++,i++){
    if(i>=end||!IsCountedPath(lines[i],".mesh")){Add(errors,Math.Min(i,end)+1,"Mesh count declares "+count+" meshes, but mesh record "+(k+1)+" is missing.");return;}
   }
   int factionCount;
   if(i>=end||!Numeric(lines[i],out factionCount)){Add(errors,Math.Min(i,end)+1,"Missing unit texture faction count.");return;}
   i++;if(factionCount<0||factionCount>100){Add(errors,i,"Invalid unit faction count.");return;}
   for(int k=0;k<factionCount;k++){
    if(i+2>=end||!IsFaction(lines[i])||!IsCountedPath(lines[i+1],".texture")||!IsCountedPath(lines[i+2],".texture")){
     Add(errors,Math.Min(i,end)+1,"Expected faction name, diffuse texture and normal texture.");return;
    }
    // Sprite is optional in the established three-line texture record variant.
    bool sprite=(i+3<end&&IsCountedPath(lines[i+3],".spr"));
    i+=sprite?4:3;
   }
   int attachmentCount;
   if(i>=end||!Numeric(lines[i],out attachmentCount)){
    // Some special mount layouts have no attachment section. Do not flag their
    // animation/skeleton block as a missing attachment count.
    if(i+2<end && IsFaction(lines[i]) && IsCountedPath(lines[i+1],".texture") && IsCountedPath(lines[i+2],".texture"))Add(errors,i+1,"Missing attachment faction count after "+factionCount+" unit factions.");
    return;
   }
   i++;if(attachmentCount<0||attachmentCount>100){Add(errors,i,"Invalid attachment faction count.");return;}
   for(int k=0;k<attachmentCount;k++){
    if(i+2>=end||!IsFaction(lines[i])||!IsCountedPath(lines[i+1],".texture")||!IsCountedPath(lines[i+2],".texture")){
     Add(errors,Math.Min(i,end)+1,"Expected attachment faction name, diffuse texture and normal texture (three lines).");return;
    }
    i+=3;
   }
  }
  public static string Check(string path){
   var lines=File.ReadAllLines(path);var errors=new List<string>();int entries=0;
   if(lines.Length==0)Add(errors,1,"File is empty.");
   int expected=-1;
   if(lines.Length>0){var nums=Regex.Matches(lines[0],@"\d+").Cast<Match>().Select(x=>x.Value).ToArray();
    if(nums.Length>=8)int.TryParse(nums[6],out expected);
    else Add(errors,1,"Unrecognized MODDB header; global entry count not checked.");
   }
   int start=1;
   for(int i=1;i<lines.Length;i++){
    if(!Term.IsMatch(lines[i].Trim()))continue;
    entries++;
    if(start>=i)Add(errors,i+1,"Empty entry before termination.");
    else{
     for(int j=start;j<i;j++){
      string line=lines[j].Trim();
      if(line.Length==0){Add(errors,j+1,"Unexpected blank line inside entry.");continue;}
      // Only verify counted strings, not numeric control records or mesh headers.
      if(j==start+1&&Regex.IsMatch(line,@"^(?:1|1\.12)\s+"))continue;
      if(IsFaction(line)||PathExt.IsMatch(line)||Regex.IsMatch(line,@"^\d+\s+[A-Za-z_][A-Za-z_0-9'-]*(?:\s+\d+)?$"))CheckCount(lines[j],j+1,errors);
     }
     CheckStandard(lines,start,i,errors);
    }
    start=i+1;
   }
   if(start<lines.Length)Add(errors,start+1,"Entry does not end with a recognized termination line.");
   if(expected>=0&&entries!=expected)Add(errors,1,"Global header declares "+expected+" entries, but "+entries+" termination-delimited entries were found.");
   var log=new StringBuilder();log.AppendLine("Fantastic Realms MODDB Builder — Whole-File Check");
   log.AppendLine("Source: "+path);log.AppendLine("Checked: "+DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
   log.AppendLine("Entries found: "+entries+"; header count: "+(expected>=0?expected.ToString():"unrecognized"));
   log.AppendLine("Findings: "+errors.Count);log.AppendLine("READ ONLY — source file was not changed.");
   log.AppendLine("This is a structural/character-count check, not a guarantee of in-game compatibility.");log.AppendLine();
   if(errors.Count==0)log.AppendLine("No issues detected by these checks.");
   else foreach(string error in errors)log.AppendLine(error);
   return log.ToString();
  }
 }
 static class Program {[STAThread]static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new MainForm());}}
}
