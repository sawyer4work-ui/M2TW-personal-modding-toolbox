Both tools have been compiled in windows so the programs do not need to be built again. Simply place the directory folder for each tool wherever it is you wish to use them from and launch the application.

MODDB builder
This tool does not write at all to your battle_models.modeldb file, it reads it only. It must be a standard formatted file, custom units are fine so long as there are not commented out blocks within it. It could potentially read the file and let you select a template but the built in checker will most likely lead to errors.

For basic mods just using existing unit mesh files searching the proper subfolder for texture assignment is rather straightforward. If using custom material this tool does not eliminate the need to know the parts required for the unit you are trying to bring in game. What it does do is make that process much faster and with the chance for far less errors.

Because CTD can occur from incompatible skeleton and animation combinations this tool is based around selecting a unit with the desired skeleton and animation to use as the template. This block of the unit entry becomes locked and the rest is editable from the top down and in any order you like. Faction counts are automatic to how many you assign with the add button. If you have custom skeletons and animations in use it should be fine, it pulls from your file to set the template.

The tool allows you to select existing sprites from your mod or base game. It is also set by default to make its own, temporary .spr file using provided dummy spearmen templates. There is a button to generate them and place them within the tools subfolder. You must manually move them to your mods sprite folder. These are NOT working sprites, they are placeholders for the game engine to find that are named correctly so no updates are needed to your battle_models file after you use the games built in sprite generation function. I am not providing instruction on how to do this as it already exists. After your sprites are generated you can use the second tool included here to convert them before placing and writing over the placeholder sprites.

The right hand pane is a live view of what you are putting together. when done and satisfied it is correct simply hit either copy button or copy and open text editor. I recommend notepad++ as it can be used to verify string counts if you want. For single upgrade level units you can just paste into your battle_models file either as a new one and edit unit count up top or as an update over an existing one. Pasting into its own notepad window is good for units with multiple armor upgrade levels so you can copy and paste at one time since the tool is for building each level individually.

Once you have the updated battle_models file the tool has a built in checker you can point towards the file so it can parse for errors. A pass check does not mean you will have no issues! It means it has passed a unit count, string count and format check. Incorrect animation combinations can still cause a CTD as with missing assets (using the tools navigation should make that difficult to do).

Batch sprite converter
This tool will convert all of the games generated .tga sprite files at once straight from .tga to .texture format. It uses a single layer dds version which does work, it currently is not programmed to make mipmaps.

It has the option to delete the tga files when done so you do not have to select around them. It does not touch the .spr files at all. If you used the MODDB builder to generate placeholder sprites when you paste your new, correct game generated sprites into your mods folder make sure you write over the placeholder ones. There should be no associated textures however if there are and your intent is to replace them then overwrite those too.

As usual for both tools, back-up your files before you make any changes! Once and update is working properly, back that up too. If you have any issues with these let me know and I will see what I can do to fix them. I have tested both and verified units placed into the game using the battle_models tool work and the placeholder sprite system works to generate new ones. I have tested the sprites from the batch converter on multiple units and there appears to be no real difference at a distance from the original ones I was using.

