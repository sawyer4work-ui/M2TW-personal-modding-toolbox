using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;

namespace FantasticRealms {
static class Codec {
  public static readonly byte[] Wrapper = new byte[] { 1,0,0,0,48,0,0,0,0,0,0,0,100,100,115,0,68,226,18,0,152,98,18,3,192,218,18,0,64,2,0,0,0,0,0,0,101,86,58,124,3,0,0,0,0,1,0,0 };
  static void Put16(byte[] a,int p,int v){a[p]=(byte)v;a[p+1]=(byte)(v>>8);}
  static void Put32(byte[] a,int p,int v){for(int i=0;i<4;i++)a[p+i]=(byte)(v>>(8*i));}
  static int U16(byte[] a,int p){return a[p]|(a[p+1]<<8);}
  public static byte[] LoadTga(string path,out int width,out int height){
    byte[] b=File.ReadAllBytes(path);
    if(b.Length<18)throw new Exception("TGA header is incomplete");
    int id=b[0], type=b[2], cmap=b[1], depth=b[16], desc=b[17];
    width=U16(b,12);height=U16(b,14);
    if(cmap!=0 || type!=2 || (depth!=24 && depth!=32))throw new Exception("Only uncompressed 24/32-bit truecolor TGAs are supported");
    if(width<4||height<4||width%4!=0||height%4!=0||width>4096||height>4096)throw new Exception("Dimensions must be multiples of four, from 4 to 4096");
    int stride=depth/8, off=18+id; long need=(long)width*height*stride;
    if(off+need>b.Length)throw new Exception("Truncated TGA pixel data");
    byte[] rgba=new byte[width*height*4];bool top=(desc&32)!=0, right=(desc&16)!=0;
    for(int y=0;y<height;y++)for(int x=0;x<width;x++){
      int src=off+(y*width+x)*stride, xx=right?width-1-x:x, yy=top?y:height-1-y;
      int dst=(yy*width+xx)*4;rgba[dst]=b[src+2];rgba[dst+1]=b[src+1];rgba[dst+2]=b[src];rgba[dst+3]=stride==4?b[src+3]:(byte)255;
    }
    return rgba;
  }
  static int C565(int r,int g,int b){return ((r*31+127)/255<<11)|((g*63+127)/255<<5)|((b*31+127)/255);}
  static void RGB565(int c,out int r,out int g,out int b){r=((c>>11)&31)*255/31;g=((c>>5)&63)*255/63;b=(c&31)*255/31;}
  static void Block(byte[] rgba,int w,int x,int y,byte[] dest,int p){
    int[] rr=new int[16],gg=new int[16],bb=new int[16],aa=new int[16];
    int lo=255,hi=0;int minLum=int.MaxValue,maxLum=int.MinValue,loC=0,hiC=0;
    for(int j=0;j<4;j++)for(int i=0;i<4;i++){
      int k=j*4+i, s=((y+j)*w+x+i)*4;
      rr[k]=rgba[s];gg[k]=rgba[s+1];bb[k]=rgba[s+2];aa[k]=rgba[s+3];
      if(aa[k]<lo)lo=aa[k];if(aa[k]>hi)hi=aa[k];
      int lum=rr[k]*299+gg[k]*587+bb[k]*114;
      int c=C565(rr[k],gg[k],bb[k]);if(lum<minLum){minLum=lum;loC=c;}if(lum>maxLum){maxLum=lum;hiC=c;}
    }
    // BC3 alpha block: 8 interpolation values, 3 bits per pixel.
    dest[p]=(byte)hi;dest[p+1]=(byte)lo;
    int[] av=new int[8];av[0]=hi;av[1]=lo;
    if(hi>lo){for(int i=1;i<=6;i++)av[i+1]=((7-i)*hi+i*lo)/7;}
    else {for(int i=1;i<=4;i++)av[i+1]=((5-i)*hi+i*lo)/5;av[6]=0;av[7]=255;}
    ulong abits=0;
    for(int k=0;k<16;k++){int best=0,err=int.MaxValue;for(int z=0;z<8;z++){int d=aa[k]-av[z],e=d*d;if(e<err){err=e;best=z;}}abits|=(ulong)best<<(3*k);}
    for(int i=0;i<6;i++)dest[p+2+i]=(byte)(abits>>(8*i));
    int c0=hiC,c1=loC;if(c0<c1){int t=c0;c0=c1;c1=t;}
    if(c0==c1){if(c0<65535)c0++;else c1--;}
    Put16(dest,p+8,c0);Put16(dest,p+10,c1);
    int r0,g0,b0,r1,g1,b1;RGB565(c0,out r0,out g0,out b0);RGB565(c1,out r1,out g1,out b1);
    int[] pr={r0,r1,(2*r0+r1)/3,(r0+2*r1)/3};
    int[] pg={g0,g1,(2*g0+g1)/3,(g0+2*g1)/3};
    int[] pb={b0,b1,(2*b0+b1)/3,(b0+2*b1)/3};
    uint bits=0;
    for(int k=0;k<16;k++){int best=0,err=int.MaxValue;for(int z=0;z<4;z++){
      int dr=rr[k]-pr[z],dg=gg[k]-pg[z],db=bb[k]-pb[z];int e=dr*dr+dg*dg+db*db;
      if(e<err){err=e;best=z;}}
      bits|=(uint)best<<(2*k);
    }
    Put32(dest,p+12,unchecked((int)bits));
  }
  public static byte[] MakeTexture(byte[] rgba,int w,int h){
    int len=w*h;byte[] output=new byte[48+128+len];Array.Copy(Wrapper,output,48);
    int d=48;output[d]=(byte)'D';output[d+1]=(byte)'D';output[d+2]=(byte)'S';output[d+3]=(byte)' ';
    Put32(output,d+4,124);Put32(output,d+8,0x81007);Put32(output,d+12,h);Put32(output,d+16,w);
    Put32(output,d+20,len);Put32(output,d+28,1);
    Put32(output,d+76,32);Put32(output,d+80,4);
    output[d+84]=(byte)'D';output[d+85]=(byte)'X';output[d+86]=(byte)'T';output[d+87]=(byte)'5';
    Put32(output,d+108,0x1000);
    int p=48+128;for(int y=0;y<h;y+=4)for(int x=0;x<w;x+=4){Block(rgba,w,x,y,output,p);p+=16;}
    if(p!=output.Length)throw new Exception("Internal BC3 size mismatch");
    return output;
  }
  public static void Verify(byte[] b,int w,int h){
    if(b.Length!=176+w*h || b[48]!=68 || b[49]!=68 || b[50]!=83 || b[51]!=32 ||
       b[132]!=68 || b[133]!=88 || b[134]!=84 || b[135]!=53)throw new Exception("Texture verification failed");
  }
}
class MainWindow:Form {
  TextBox folder=new TextBox(),log=new TextBox();CheckBox delete=new CheckBox(),overwrite=new CheckBox();Button run=new Button(),browse=new Button();
  public MainWindow(){
    Text="Fantastic Realms — Sprite Batch Converter";Width=760;Height=490;MinimumSize=new Size(650,390);StartPosition=FormStartPosition.CenterScreen;
    var top=new Panel(){Dock=DockStyle.Top,Height=126};Controls.Add(top);
    var lbl=new Label(){Text="Folder containing generated TGA sprites:",Left=12,Top=12,AutoSize=true};top.Controls.Add(lbl);
    folder.SetBounds(12,35,620,24);folder.Anchor=AnchorStyles.Left|AnchorStyles.Top|AnchorStyles.Right;top.Controls.Add(folder);
    browse.Text="Browse…";browse.SetBounds(640,33,96,28);browse.Anchor=AnchorStyles.Top|AnchorStyles.Right;top.Controls.Add(browse);
    browse.Click+=(s,e)=>{using(var f=new FolderBrowserDialog()){f.Description="Select the sprite TGA folder";if(Directory.Exists(folder.Text))f.SelectedPath=folder.Text;if(f.ShowDialog()==DialogResult.OK)folder.Text=f.SelectedPath;}};
    delete.Text="Delete source TGAs after successful conversion";delete.SetBounds(12,69,350,24);top.Controls.Add(delete);
    overwrite.Text="Overwrite existing .texture files";overwrite.SetBounds(380,69,300,24);top.Controls.Add(overwrite);
    run.Text="Convert All TGAs";run.SetBounds(12,98,165,27);top.Controls.Add(run);
    var note=new Label(){Text="Uncompressed 24/32-bit TGA → BC3/DXT5 → Medieval II .texture (no mipmaps). .spr files untouched.",Left=188,Top=103,AutoSize=true};top.Controls.Add(note);
    log.Multiline=true;log.ReadOnly=true;log.ScrollBars=ScrollBars.Both;log.WordWrap=false;log.Dock=DockStyle.Fill;Controls.Add(log);log.BringToFront();top.BringToFront();
    run.Click+=(s,e)=>ConvertAll();
    Log("Ready. Original TGAs are retained unless you select deletion.");
  }
  void Log(string s){log.AppendText(s+Environment.NewLine);}
  void ConvertAll(){
    string dir=folder.Text.Trim();if(!Directory.Exists(dir)){MessageBox.Show("Select a valid folder first.");return;}
    string[] files=Directory.GetFiles(dir,"*.tga",SearchOption.TopDirectoryOnly);
    if(files.Length==0){MessageBox.Show("No TGA files found in this folder.");return;}
    if(delete.Checked && MessageBox.Show("Delete each original TGA ONLY after its .texture file is successfully written and checked?","Confirm deletion",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes)return;
    if(overwrite.Checked && MessageBox.Show("Existing .texture files may be replaced. Continue?","Confirm overwrite",MessageBoxButtons.YesNo,MessageBoxIcon.Warning)!=DialogResult.Yes)return;
    run.Enabled=false;int ok=0,skipped=0,failed=0;Log("--- Processing "+files.Length+" TGA(s) ---");
    try{foreach(string src in files){
      string dst=Path.ChangeExtension(src,".texture"),temp=dst+".tmp";
      try{
        if(File.Exists(dst)&&!overwrite.Checked){Log("SKIP (exists): "+Path.GetFileName(dst));skipped++;continue;}
        int w,h;byte[] rgba=Codec.LoadTga(src,out w,out h);byte[] output=Codec.MakeTexture(rgba,w,h);Codec.Verify(output,w,h);
        if(File.Exists(temp))File.Delete(temp);File.WriteAllBytes(temp,output);
        if(new FileInfo(temp).Length!=output.Length)throw new Exception("Written size mismatch");
        using(var f=File.OpenRead(temp)){byte[] hd=new byte[176];if(f.Read(hd,0,176)!=176 || hd[48]!=68 || hd[132]!=68)throw new Exception("Output header verification failed");}
        if(File.Exists(dst))File.Delete(dst);File.Move(temp,dst);
        if(delete.Checked)File.Delete(src);
        Log("OK: "+Path.GetFileName(src)+" -> "+Path.GetFileName(dst)+" ("+w+"x"+h+")");ok++;
      }catch(Exception ex){failed++;Log("ERROR: "+Path.GetFileName(src)+" — "+ex.Message);try{if(File.Exists(temp))File.Delete(temp);}catch{}}
      Application.DoEvents();
    }}finally{run.Enabled=true;}
    Log("Complete: "+ok+" converted, "+skipped+" skipped, "+failed+" failed.");
    MessageBox.Show("Finished: "+ok+" converted, "+skipped+" skipped, "+failed+" failed.","Sprite Converter");
  }
}
static class Program {[STAThread]static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new MainWindow());}}
}
