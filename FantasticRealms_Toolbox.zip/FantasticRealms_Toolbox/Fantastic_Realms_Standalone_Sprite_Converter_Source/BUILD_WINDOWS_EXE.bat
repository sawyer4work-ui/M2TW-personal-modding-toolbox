@echo off
setlocal
cd /d "%~dp0"
set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if exist "%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe" set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" (
 echo ERROR: .NET Framework 4.x C# compiler not found.
 echo Enable/install .NET Framework 4.x or build with Visual Studio.
 pause
 exit /b 1
)
"%CSC%" /nologo /target:winexe /optimize+ /out:FantasticRealmsSpriteConverter.exe /reference:System.dll /reference:System.Drawing.dll /reference:System.Windows.Forms.dll FantasticRealmsSpriteConverter.cs
if errorlevel 1 (
 echo Build failed. Please copy the errors when asking for help.
) else (
 echo Build succeeded: FantasticRealmsSpriteConverter.exe
 echo You can move this EXE to another Windows PC with .NET Framework 4.x.
)
pause
