FANTASTIC REALMS SPRITE BATCH CONVERTER — Standalone Windows build

1. Extract the ZIP to a folder on your Windows PC.
2. Double-click BUILD_WINDOWS_EXE.bat.
3. The script uses the .NET Framework 4.x C# compiler built into many Windows installations.
   It does NOT need Python, ImageMagick, or internet access.
   If Windows lacks the compiler, build with Visual Studio's C# compiler.
4. Double-click FantasticRealmsSpriteConverter.exe.
5. Browse to a folder with generated TGA files, click Convert All TGAs.
6. Copy the resulting .texture files to your mod's sprite folder.

IMPORTANT:
- This is a first implementation of an independent DXT5 compressor, limited testing in Medieval II.
- Start with 1-2 disposable sprite images and verify their in-game appearance.
- Keep 'Delete source TGAs' UNCHECKED until the game test succeeds.
- Handles uncompressed 24/32-bit truecolor TGAs, dimensions multiples of four.
- Outputs BC3/DXT5, one mipmap level, with the 48-byte Medieval II wrapper
  copied from the verified 256x256 City Guard example.
- The 48-byte wrapper is based on a 256x256 sample; use 256x256 sprites
  until other dimensions are separately verified in game.
- Existing .texture files are skipped by default.
- .spr files and unrelated files are not modified.
- This tool uses an original basic BC3 encoder. Visual quality may differ
  from GIMP/ImageMagick. Check transparency and distant sprites in-game.
- It is NOT derived from or bundled with M2TWMT.exe.
